# Physics-aware wellbore trajectory study

This folder contains the code and evidence behind my ROGII research notebook.
It includes a reproducible reimplementation, the audited historical
121-feature builder and an adapter for supplying the external files used by the
scored pipeline.

## In brief

The task is to predict the hidden TVT suffix of a directional well from its
visible prefix, geometry, gamma ray log and a reference type well. A well-level
split turned out to be too optimistic because nearby or very similar wells
could appear in different folds. I therefore split connected components of an
XY/GR similarity graph.

The scored research path combined a particle filter, GeoHMM, HGRG, Meta-State
and bounded boundary/shape corrections. The reimplemented branch refits every
learned model, spatial RBF and stack weight inside outer component folds. I ran
that contract on two component-disjoint halves of the full 320-well universe.

The historical graph scored 6.536 on the visible partition and 9.091 on the
hidden partition, but completed after the deadline. I treat that as one result
for the whole graph, not as an ablation of each block. Recreating the exact CSV
also requires the external model artifacts used by that run.

## Publishing on Kaggle

Import `portfolio_notebook_executed.ipynb` as the notebook. Saved outputs make
it readable on its own, but rerunning it also requires the companion files in
`src/`, `evidence/` and `artifacts/`. Build the small companion archive with:

```bash
make kaggle-bundle
```

Upload the files under `dist/` as a Kaggle Dataset and attach it to the
notebook. See [KAGGLE_UPLOAD.md](KAGGLE_UPLOAD.md) for the exact layout.

## One-command reproduction

```bash
make reproduce
```

On Windows or on a minimal machine without GNU Make, the equivalent command is:

```bash
python reproduce.py
```

This command creates a pinned local environment, runs all model stages on
deterministic synthetic wells, performs nested component CV and one untouched
holdout evaluation, rebuilds and executes `portfolio_notebook.ipynb`, and
runs the test suite and verifies every tracked output from that run by SHA-256.

For the official data (the data are not redistributed):

```bash
make reproduce-full DATA_ROOT=/path/to/rogii-wellbore-geology-prediction.zip
```

An inexpensive official-schema integration check is also available:

```bash
make realdata-smoke DATA_ROOT=/path/to/raw-data-directory-or-zip
```

It uses 18 wells and reduced PF/HMM budgets. It verifies raw-data wiring and
the complete nested graph, but is not a competition-score estimate. Components
are built only within that 18-well subset, so this target is an integration
test—not a substitute for the full-universe leakage graph.

For the larger CPU validation used in this portfolio:

```bash
make realdata-nested-160 DATA_ROOT=/path/to/raw-data-directory-or-zip
```

This first constructs the graph over all 320 available training wells, then
samples whole components up to 160 wells and runs 5 outer × 3 inner folds.
PF/HMM compute is reduced so this is a validation of the complete graph and
its generalization direction, not a byte-equivalent run of the expensive
historical submission policy.

The complete two-panel research protocol (primary 160, graph audit, predeclared
regret router, frozen expanded policy, and the complementary 160-well
confirmation) is one command:

```bash
make realdata-research-320 DATA_ROOT=/path/to/raw-data-directory-or-zip
```

The full profile uses 12 PF seeds × 500 particles, stride-6 GeoHMM, five outer
folds, four inner folds and 5,000 component bootstrap draws. It is intentionally
much slower than the smoke profile.

## Current real-data result

The reduced-compute clean-room graph has now been run over two disjoint halves
of the full 320-well component universe:

| Component panel | Incumbent outer OOF | Sequential outer OOF | Gain |
|---|---:|---:|---:|
| Primary160 (96 development components) | 15.5551 | 14.8993 | +0.6558 ft |
| Complement160 (100 development components) | 13.5177 | 12.6000 | +0.9177 ft |

The corresponding run-level holdout gains were +0.5928 ft across 23 components
and +0.6587 ft across 24 components. These are validation RMSE values for the
retrained clean-room parent, not estimates of the historical 6.372 notebook or
the competition leaderboard.

A Ridge-heavy policy looked excellent on Primary160, then failed on the
component-disjoint Complement160 OOF (13.5177 incumbent → 14.3089 expanded;
−0.7912 ft). This negative transfer is retained as a central result rather
than hidden. The HGRG-centered sequential path is the more defensible method.
Likewise, removing Meta-State gained 0.0481 ft on primary OOF but lost 0.0543
ft on complementary OOF; it remains a post-hoc HOLD rather than a promoted
weight change.

## What is actually implemented

```text
official/synthetic raw wells
    ├── geological similarity graph ──> component-disjoint folds + holdout
    ├── visible-prefix inference view (suffix TVT removed)
    ├── Monte-Carlo PF ───────────────┐
    ├── forward/backward GeoHMM ──────┼──> HGRG
    ├── 121 target-local features ────┘       │
    │      └── Ridge + nonlinear control      v
    └── outer-training-only RBF ───────> correlated GLS + RTS Meta-State
                                               │
                                               v
                                   Prefix-Boundary → conditional shape
                                               │
                             inner-OOF convex stack (research control)
```

The implementations are not plotting stubs:

- `particle.py` propagates and resamples particles, returns every seed path and
  predictive log evidence.
- `geohmm.py` constructs the TVT × slope state grid and executes checkpointed
  forward/backward inference.
- `features.py` constructs a readable clean-room version of the 121-name
  FAST-SAFE schema for nested retraining; `historical_features.py` separately
  vendors the actual audited notebook formulas and their source hashes.
- `hgrg.py` implements the frozen regret equation and movement budgets.
- `physics.py` and `meta_state.py` implement a clean-room structural
  observation + correlated GLS + constant-acceleration RTS state-space fusion.
- `overlays.py` implements a clean-room fixed-window prefix correction and the
  formula-faithful conditional shape correction.
- `stack.py` fits nonnegative, sum≤1 convex weights from inner-OOF predictions.
- `pipeline.py` connects all blocks, refitting learned state inside every outer
  component fold and applying the frozen graph once to the untouched holdout.
- `deployment.py` refits the selected clean-room graph, rejects target-bearing
  test objects, preserves sample-submission ID order and records CSV hashes.
- `parents.py` verifies a pinned historical expert artifact before it can enter
  the scored-lineage overlay path.

See [implementation map](docs/IMPLEMENTATION_MAP.md) and
[method cards](docs/METHOD_CARDS.md) for formulas, pseudocode, complexity,
closest baselines, ablations and failure modes. The
[historical-parity ledger](docs/HISTORICAL_PARITY_GAPS.md) lists every exact,
analogue and externally blocked block. The
[real-data nested result](docs/REALDATA_NESTED_RESULTS.md) gives the complete
two-panel score and negative-transfer audit.

## Three distinct reproducibility claims

| Mode | What it proves | Required inputs |
|---|---|---|
| `make reproduce` | Clean-room code path, target isolation, nested split, figures and notebook execution | Repository only |
| `make reproduce-full` | Clean-room algorithmic retraining and a new component-disjoint holdout result | Official competition ZIP/directory |
| exact historical bytes | Same historical prediction/CSV bytes | Official data **plus** pinned external pretrained artifacts and their hashes |

The last mode is intentionally fail-closed in `configs/exact_artifacts.json`.
The original scored notebook loaded third-party feature/model packages; until
their exact versions and hashes are supplied, claiming byte identity would be
false.

## Validation contract

The final experiment performs the following sequence:

1. Build graph-connected geological components before model fitting.
2. Reserve complete components as a run-level holdout.
3. Within each outer development fold, fit the 121-feature estimators and RBF
   using only outer-training components.
4. Produce inner-OOF expert paths on the outer-training components and fit the
   residual stack there.
5. Apply that fold-frozen graph to outer validation components.
6. Fit one final stack from development outer-OOF predictions, refit the base
   models on all development components, and open the holdout once.
7. Bootstrap complete components, never individual rows.

Target-free PF/HMM/features may be cached because each depends on only one
well's visible prefix, suffix covariates and type well. Model-facing objects
have no truth field; scorer labels live in a separate wrapper. Official-data
mode also refuses to synthesize a broken prefix from truth.

## Scored lineage versus research controls

The historical 9.091 graph was:

```text
incumbent → HGRG → Meta-State → Prefix-Boundary → conditional GeoHMM shape
```

This repository does **not** relabel its retrained parent as that historical
incumbent. The scored parent also contained SP45/beam selection, robust
polynomial projection, visible-prefix calibration, contact logic, DTRT and
external learned packages. HGRG and conditional shape are formula-faithful;
the new RBF/Meta-State and fixed-window boundary modules are clean-room
analogues. Exact historical expert paths must enter through the hash-verified
`HistoricalArtifactParent` adapter.

The 121-feature nonlinear retrain, nested residual stack and optimizer sweep
were separate controls. They are implemented and evaluated here, but their
gains are not attributed to the historical score. Likewise, results from the
40-, 80- and 160-well panels are not added across incompatible parents.

The latest optimizer control is a useful negative result: fold-specific choices
included higher L2, adaptive learning rate, modified Huber loss, label
smoothing, 300 epochs and a softened decoder. The nested candidate nevertheless
worsened 9.4531 → 9.4680 on its own Dev160 contract, improved only 2/5 folds,
and had a component-bootstrap interval crossing zero. It was held before the
confirmation labels were opened.

## Repository layout

```text
README.md
portfolio_notebook.ipynb
portfolio_notebook_executed.ipynb       # produced by make reproduce
evidence/                               # source-backed and generated evidence
src/rogii_portfolio/                    # complete model implementation
scripts/                                # bootstrap, reproduce, notebook, verify
configs/                                # smoke, full and exact-artifact contracts
tests/                                  # target isolation and end-to-end tests
docs/                                   # implementation map and method cards
requirements.txt / environment.yml
LICENSE
Makefile
```

## Research lessons

I encountered four different overfitting mechanisms: geological split leakage,
adaptive reuse of transfer panels, repeated search inside one PF neighbourhood,
and operational overfitting to an unrepresentative runtime canary. They need
different controls. A component graph does not fix research-selection bias; a
bootstrap does not include the uncertainty introduced by trying many ideas; a
correct CSV does not prove that hidden execution will finish.

That last point was costly. In a code competition, the model, queue and hidden
execution time are all part of the method. The final run landed in the displayed
bronze-score band but completed after the cutoff, so it was ineligible. I was
disappointed, but the failure changed the way I now define an experiment: the
runtime protocol and artifact manifest must be frozen beside the estimator.

And, slightly less solemnly, the competition seems to have assigned me a small
mathematics degree: Bayesian filtering, HMM dynamic programming, generalized
least squares, RTS smoothing, graph connected components, signal processing
and constrained optimization. I probably need to study more mathematics—before
the next deadline, rather than while watching the submission queue.
